from pymongo import MongoClient
from bson.objectid import ObjectId
import urllib.parse

class AnimalShelter:
    """
    CRUD operations for Animal collection in MongoDB
    """

class AnimalShelter:
    """
    CRUD operations for Animal collection in MongoDB
    """

    def __init__(self, username, password):
        # URL encode to sanitize the input
        USER = urllib.parse.quote_plus(username)
        PASS = urllib.parse.quote_plus(password)
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 31045
        DB = 'AAC'
        COL = 'animals'

        # Initialize connection using dynamic credentials
        self.client = MongoClient(f'mongodb://{USER}:{PASS}@{HOST}:{PORT}')
        self.database = self.client[DB]
        self.collection = self.database[COL]

    def create(self, data):
        """
        Insert a new document into the collection.
        Returns True if successful, False otherwise.
        """
        if data:
            try:
                self.collection.insert_one(data)
                return True
            except Exception as e:
                print(f"Create Error: {e}")
                return False
        else:
            raise Exception("Nothing to save, because data parameter is empty")

    def read(self, query):
        """
        Query documents from the collection.
        Returns a list of matching documents.
        """
        try:
            result = list(self.collection.find(query))
            return result
        except Exception as e:
            print(f"Read Error: {e}")
            return []

    def update(self, query, new_values):
        """
        Update one or more documents that match the query.
        Returns the number of documents modified.
        """
        if query and new_values:
            try:
                result = self.collection.update_many(query, {'$set': new_values})
                return result.modified_count
            except Exception as e:
                print(f"Update Error: {e}")
                return 0
        else:
            raise Exception("Query and new_values must both be provided.")

    def delete(self, query):
        """
        Delete one or more documents that match the query.
        Returns the number of documents deleted.
        """
        if query:
            try:
                result = self.collection.delete_many(query)
                return result.deleted_count
            except Exception as e:
                print(f"Delete Error: {e}")
                return 0
        else:
            raise Exception("Query parameter is required.")

